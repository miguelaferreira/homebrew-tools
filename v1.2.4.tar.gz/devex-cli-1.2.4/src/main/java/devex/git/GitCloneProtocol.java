package devex.git;

public enum GitCloneProtocol {
    SSH, HTTPS
}
